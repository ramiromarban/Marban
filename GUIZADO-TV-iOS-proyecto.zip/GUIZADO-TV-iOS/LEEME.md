# GUIZADO TV para iPhone · proyecto nativo 1.0

Este paquete contiene código SwiftUI y un proyecto de Xcode para iPhone con iOS 16 o posterior. Es una primera adaptación nativa del proyecto de Fire TV. **No contiene una IPA firmada ni una aplicación ya instalada.**

Se incluye también `GENERAR-IPA-DESDE-WINDOWS.md` y un workflow manual de GitHub Actions para compilar en macOS remoto. **Preparado, todavía no ejecutado**: requiere acceso a un repositorio y, para una IPA firmada, los materiales de firma Apple.

## Si solo tienes Windows

Puedes guardar y editar este proyecto desde Windows. Para compilarlo con las herramientas de Apple necesitas acceso a un Mac con Xcode, propio, prestado o remoto. Para instalarlo en tu iPhone se necesita además configurar la firma con tu cuenta de Apple. No se contrató ningún servicio ni se publicaron tus archivos.

Downloader, los códigos de AFTVnews y los archivos APK corresponden a Android/Fire TV; no sirven para instalar esta versión en iPhone.

## Compilar e instalar desde un Mac

1. Extrae el ZIP en el Mac y abre `GuizadoTV.xcodeproj` con una versión de Xcode compatible con tu iPhone.
2. Selecciona el target **GuizadoTV**, abre **Signing & Capabilities**, elige tu Team y activa la firma automática. Cambia `tv.guizado.ios` por un identificador único de tu cuenta si Xcode lo solicita.
3. Conecta tu iPhone, completa las indicaciones de confianza/modo de desarrollador que soliciten Apple y Xcode, selecciona el dispositivo y pulsa Run.
4. Para distribución mediante TestFlight se requiere configurar Apple Developer Program y App Store Connect. No se ha creado una cuenta, una ficha, una firma ni una versión en TestFlight.

Para comprobar una compilación sin firma en el simulador, ejecuta `sh build-simulator.sh` en el Mac. Para ejecutar las comprobaciones del núcleo, usa `sh check-core.sh`. Ambos comandos están preparados, **no ejecutados en este entorno Windows**.

## Incluido en esta primera versión

- Nombre GUIZADO TV, iconos G y entrada animada de tres segundos, con opción de reducir movimiento.
- Inicio con películas y recomendaciones a partir de géneros de tus favoritos/progreso. Sin una fila de “Seguir viendo” en Inicio.
- Navegación táctil nativa: Inicio, Películas, Series, TV y Mi espacio.
- Búsqueda, géneros, estrenos del año, recién añadidas y paginación en Películas/Series.
- Temporadas, episodios, reproducción directa y siguiente episodio automático con cancelación.
- Reanudación local, favoritos separados y hasta seis perfiles locales.
- Reproductor de Apple con controles de avance, selección de audio/subtítulos disponibles y compatibilidad de Picture in Picture/AirPlay según dispositivo y fuente.
- Preferencia de calidad sin límite artificial de resolución y modo de ahorro. La calidad real sigue dependiendo de la fuente, la conexión y el dispositivo.
- Categorías específicas de TV: México, comedia, noticias, 24/7, deportes, documentales, estilo de vida, entretenimiento, infantil, música y regionales.
- Catálogo consultado por internet, caché de catálogo/imágenes y recursos de arranque: 24 títulos y 288 carátulas/logos del proyecto existente. Las imágenes nuevas se solicitan a las fuentes y tienen recuperación alternativa por coincidencia de título/año.
- Lista pública en español de iptv-org, agrupando distintas señales del mismo canal. Los accesos a realities abren sus sitios oficiales y no prometen emisiones fuera de temporada o sin autorización del proveedor.

## Límites y comprobaciones pendientes

La aplicación no necesita que la laptop esté encendida: consulta las fuentes desde el iPhone. Necesita internet y depende de que esas fuentes sigan disponibles. No descarga películas para uso sin conexión.

No se ha compilado con Xcode, firmado, instalado ni probado reproducción, subtítulos, PiP, AirPlay o rendimiento en un iPhone. El análisis de sintaxis de Swift en Windows no sustituye una compilación con el SDK de Apple. Los scripts de comprobación necesitan ejecutarse en el Mac antes de entregar una IPA.

Esta adaptación no incluye todavía la guía EPG, sincronización con Fire TV, avisos de episodios ni un servicio de actualizaciones de la aplicación. Los perfiles y el progreso son locales a este iPhone. Consultar contenido nuevo no instala versiones nuevas de la app. No se garantiza compatibilidad con todas las señales ni fuentes de Fire TV.

El reproductor admite formatos compatibles con AVPlayer. No convierte formatos ni evade DRM, suscripciones o restricciones geográficas. Un adaptador HTTP vinculado exclusivamente a 127.0.0.1 añade el Referer cuando una fuente HLS lo necesita; se ejecuta dentro del iPhone y se detiene con el reproductor. Deben probarse variantes, subtítulos, rangos y reconexión. La excepción ATS se limita a medios de AVFoundation; las consultas URLSession conservan las comprobaciones TLS de Apple, por lo que algunas fuentes HTTP pueden no funcionar.

## Verificación previa a una distribución

- Ejecutar compilación de simulador y `check-core.sh`; revisar advertencias con el SDK instalado.
- Probar películas y series reales, reanudación después de cerrar la app y siguiente episodio de temporada/página.
- Probar TV HTTPS/HTTP, señales caídas, selección de calidad/subtítulos y controles que se ocultan.
- Probar rotación, modo de reducir movimiento, bloqueo de pantalla, PiP y AirPlay.
- Comprobar icono/nombre, consumo de memoria, almacenamiento, imágenes faltantes y redes lentas.
- Antes de publicar, revisar permisos de uso/distribución de catálogo, imágenes y canales, y requisitos de Apple.

## Documentación oficial

- Instalación en dispositivos registrados: https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices
- Distribución y beta: https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases

No hay claves de firma ni datos personales incluidos en este paquete.
