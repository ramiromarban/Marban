# Generar la IPA desde Windows con un Mac remoto

Todavía no se ha generado una IPA. Se añadió un flujo manual de GitHub Actions para compilar en un runner macOS con Xcode. El flujo no se ha ejecutado: este chat no tiene un repositorio/cuenta de GitHub conectados ni credenciales de firma Apple.

## Preparación del repositorio

1. Usa un repositorio de tu cuenta GitHub y sube **el contenido** de esta carpeta en su raíz: `GuizadoTV.xcodeproj`, `GuizadoTV`, `Tests`, `ci`, los scripts y la carpeta oculta `.github`. No subas únicamente el ZIP. No incluyas certificados ni contraseñas en archivos del repositorio.
2. En GitHub abre **Actions → GUIZADO TV - IPA → Run workflow**. La ejecución es manual y no se activa por cada cambio.
3. Revisa la disponibilidad y los límites de minutos macOS de tu cuenta antes de ejecutarlo. No se ha contratado ni cobrado ningún servicio desde este chat.

## Primera compilación sin firma

Deja `signed` desactivado. El flujo ejecutará las comprobaciones del núcleo, compilará para un iPhone arm64 y empaquetará el resultado en `GUIZADO-TV-sin-firma.ipa`. Si hay errores de compilación, el flujo se detiene: no produce una IPA ficticia.

Si la compilación termina correctamente, descarga el artifact desde la ejecución de Actions. Incluye la IPA, su SHA256 y el estado de firma. **Una IPA sin firma no se instala directamente en el iPhone.** No es una app de simulador; requiere un proceso de firma e instalación compatible con tu dispositivo.

## IPA firmada para tu iPhone

Este flujo admite perfiles de desarrollo y ad-hoc que ya incluyan el iPhone. Para este camino necesitas un certificado con su clave privada en formato P12 y un perfil de aprovisionamiento válidos de tu cuenta Apple. La obtención de estos archivos y el registro del dispositivo no se han completado.

Configura en **Settings → Secrets and variables → Actions → Repository secrets**:

- `BUILD_CERTIFICATE_BASE64`: contenido Base64 del P12.
- `P12_PASSWORD`: contraseña del P12.
- `BUILD_PROVISION_PROFILE_BASE64`: contenido Base64 del perfil mobileprovision.
- `KEYCHAIN_PASSWORD`: una contraseña aleatoria para el llavero temporal del runner.

No compartas esos valores en el chat. Introduce el Bundle ID correspondiente a tu perfil y activa `signed` al ejecutar el flujo. Se comprueban caducidad, Bundle ID y presencia de dispositivos registrados; se importa la identidad en un llavero temporal y se exporta la IPA. El runner comprueba la firma antes de guardar el artifact `GUIZADO-TV-iOS-firmada`. Los archivos temporales de firma se eliminan al finalizar el script.

La IPA firmada solo se instalará donde el perfil y el método de distribución lo permitan. No se ha configurado TestFlight ni publicación en App Store. Compilar y verificar la firma no sustituye probar reproducción, controles, carátulas y rendimiento en tu iPhone.

## Estado de validación en Windows

- Sintaxis Swift: sin errores detectados por el analizador.
- Referencias del proyecto, plist, esquema, iconos y recursos: comprobados.
- Generación de opciones de firma: comprobada con perfiles sintéticos, sin datos reales; acepta desarrollo/ad-hoc y rechaza perfil caducado, Bundle ID distinto o ausencia de dispositivos.
- Compilación con Xcode, scripts Bash, ejecución del workflow y pruebas en iPhone: pendientes de acceso al Mac remoto.

Referencias oficiales:
- https://docs.github.com/en/actions/how-tos/deploy/deploy-to-third-party-platforms/sign-xcode-applications
- https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices
